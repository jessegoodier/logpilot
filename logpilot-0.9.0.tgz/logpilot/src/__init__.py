"""
logPilot - A web-based Kubernetes log viewer
"""

__version__ = "0.9.0"
